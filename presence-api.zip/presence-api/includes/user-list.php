<?php
/**
 * User list: online filter view.
 *
 * @package Presence_API
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds an "Online" view to the users list table.
 *
 * Displays a tab alongside the role-based views (All | Administrator | Editor | etc.)
 * that filters the list to only show users with active presence entries.
 *
 * @param array $views Existing views.
 * @return array Modified views.
 */
function wp_presence_users_views( $views ) {
	if ( ! current_user_can( 'edit_posts' ) ) {
		return $views;
	}

	$entries      = wp_get_presence( wp_presence_admin_room() );
	$online_count = count( wp_presence_online_user_ids( $entries ) );
	$is_current   = isset( $_GET['presence_status'] ) && 'online' === $_GET['presence_status']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

	$class = $is_current ? 'current' : '';
	$url   = wp_nonce_url( admin_url( 'users.php?presence_status=online' ), 'presence_online_filter' );

	$views['presence_online'] = sprintf(
		'<a href="%s" class="%s">%s <span class="count">(%d)</span></a>',
		esc_url( $url ),
		$class,
		esc_html__( 'Online', 'presence-api' ),
		$online_count
	);

	// Remove "current" from "All" when our filter is active.
	if ( $is_current && isset( $views['all'] ) ) {
		$views['all'] = str_replace( 'class="current"', '', $views['all'] );
	}

	return $views;
}

/**
 * Filters the users query to only include online users when presence_status=online.
 *
 * Stands down in Network Admin. is_admin() is true there too, and the Network
 * Users list runs its own WP_User_Query, so without this the network "Online"
 * view would have its network-wide set of IDs replaced with the ones online on
 * whichever site the request resolved to.
 *
 * @param WP_User_Query $query The user query.
 */
function wp_presence_filter_online_users( $query ) {
	if ( ! is_admin() || is_network_admin() || ! current_user_can( 'edit_posts' ) ) {
		return;
	}

	if ( empty( $_GET['presence_status'] ) || 'online' !== $_GET['presence_status'] ) {
		return;
	}

	if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'presence_online_filter' ) ) {
		return;
	}

	$entries = wp_get_presence( wp_presence_admin_room() );

	$query->set( 'include', wp_presence_online_user_ids( $entries ) );
}
