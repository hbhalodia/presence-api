<?php
/**
 * Hooks for the parts of the plugin bound for core.
 *
 * @package Presence_API
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'init', 'wp_presence_register_post_type_support' );
add_action( 'rest_api_init', 'wp_presence_register_rest_routes' );

add_action( 'wp_delete_expired_presence_data', 'wp_delete_expired_presence_data' );
add_action( 'admin_init', 'wp_presence_schedule_cleanup' );
add_action( 'admin_init', 'wp_presence_add_privacy_policy_content' );
add_filter( 'wp_privacy_personal_data_exporters', 'wp_presence_register_personal_data_exporter' );
add_filter( 'wp_privacy_personal_data_erasers', 'wp_presence_register_personal_data_eraser' );
// phpcs:ignore WordPress.WP.CronInterval -- 60-second interval is intentional for presence cleanup.
add_filter( 'cron_schedules', 'wp_presence_cron_schedules' );
add_filter( 'map_meta_cap', 'wp_presence_map_meta_cap', 10, 4 );

add_action( 'wp_login', 'wp_presence_on_login', 10, 2 );
add_action( 'wp_logout', 'wp_presence_on_logout', 10, 1 );
add_action( 'deleted_user', 'wp_presence_on_user_removed', 10, 1 );

add_action( 'wp_default_scripts', 'wp_presence_register_packages_scripts' );
add_action( 'admin_enqueue_scripts', 'wp_presence_enqueue_heartbeat_ping' );
add_action( 'wp_enqueue_scripts', 'wp_presence_enqueue_heartbeat_ping' );
// Priority 9 so the admin/online write lands before any widget reads the room at 10.
add_filter( 'heartbeat_received', 'wp_presence_admin_heartbeat_received', 9, 3 );
add_filter( 'heartbeat_received', 'wp_presence_online_hash_heartbeat_received', 10, 2 );
add_filter( 'heartbeat_received', 'wp_presence_editor_heartbeat_received', 10, 3 );
add_filter( 'site_status_tests', 'wp_presence_site_status_tests' );

add_action( 'wp_after_insert_post', 'wp_presence_on_agent_post_saved', 10, 2 );

// Outside the switch: presence-ping.js needs the token on every admin page, faces or not.
add_filter( 'wp_refresh_nonces', 'wp_presence_refresh_screen_token', 10, 3 );
